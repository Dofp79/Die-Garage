package model;

public class Parkplatz {
    private Fahrzeug fahrzeug;

    public boolean istFrei() {
        return fahrzeug == null;
    }

    public Fahrzeug getFahrzeug() {
        return fahrzeug;
    }

    public void setFahrzeug(Fahrzeug fahrzeug) {
        this.fahrzeug = fahrzeug;
    }
}
