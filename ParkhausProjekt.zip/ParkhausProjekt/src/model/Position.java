package model;

public class Position {
    private int etage;
    private int platz;

    public Position(int etage, int platz) {
        this.etage = etage;
        this.platz = platz;
    }

    public int getEtage() {
        return etage;
    }

    public int getPlatz() {
        return platz;
    }

    @Override
    public String toString() {
        return "Etage " + etage + ", Platz " + platz;
    }
}
