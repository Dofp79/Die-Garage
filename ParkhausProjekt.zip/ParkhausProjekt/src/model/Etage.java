package model;

import java.util.ArrayList;
import java.util.List;


public class Etage {
    private int nummer;
    private List<Parkplatz> plaetze;

    public Etage(int nummer, int anzahlPlaetze) {
        this.nummer = nummer;
        this.plaetze = new ArrayList<>();
        for (int i = 0; i < anzahlPlaetze; i++) {
            plaetze.add(new Parkplatz());
        }
    }

    public int getNummer() {
        return nummer;
    }

    public List<Parkplatz> getPlaetze() {
        return plaetze;
    }
}
