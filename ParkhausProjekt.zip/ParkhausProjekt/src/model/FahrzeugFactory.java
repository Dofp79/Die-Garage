package model;

public class FahrzeugFactory {

    public static Fahrzeug erzeugeFahrzeug(String typ, String nummernschild) {
        if (typ.equalsIgnoreCase("auto")) {
            return new Auto(nummernschild);
        } else if (typ.equalsIgnoreCase("motorrad")) {
            return new Motorrad(nummernschild);
        } else {
            throw new IllegalArgumentException("Unbekannter Fahrzeugtyp: " + typ);
        }
    }
}
