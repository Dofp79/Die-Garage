package model;

public abstract class Fahrzeug {
    private String nummernschild;

    public Fahrzeug(String nummernschild) {
        this.nummernschild = nummernschild;
    }

    public String getNummernschild() {
        return nummernschild;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + " [" + nummernschild + "]";
    }
}
