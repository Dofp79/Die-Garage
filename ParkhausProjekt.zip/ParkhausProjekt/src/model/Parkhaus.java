package model;

import java.util.*;

public class Parkhaus {
    private List<Etage> etagen;

    public Parkhaus(int anzahlEtagen, int plaetzeProEtage) {
        etagen = new ArrayList<>();
        for (int i = 0; i < anzahlEtagen; i++) {
            etagen.add(new Etage(i, plaetzeProEtage));
        }
    }

    public Position findeFreienPlatz() {
        for (Etage etage : etagen) {
            for (int platzIndex = 0; platzIndex < etage.getPlaetze().size(); platzIndex++) {
                Parkplatz parkplatz = etage.getPlaetze().get(platzIndex);
                if (parkplatz.istFrei()) {
                    return new Position(etage.getNummer(), platzIndex);
                }
            }
        }
        return null;
    }

    public void parkeEin(Fahrzeug fahrzeug, Position position) {
        Parkplatz platz = etagen.get(position.getEtage()).getPlaetze().get(position.getPlatz());
        platz.setFahrzeug(fahrzeug);
    }

    public void entferneFahrzeug(Position position) {
        Parkplatz platz = etagen.get(position.getEtage()).getPlaetze().get(position.getPlatz());
        platz.setFahrzeug(null);
    }

    public Position findeFahrzeugPosition(String nummernschild) {
        for (Etage etage : etagen) {
            List<Parkplatz> plaetze = etage.getPlaetze();
            for (int i = 0; i < plaetze.size(); i++) {
                Fahrzeug fahrzeug = plaetze.get(i).getFahrzeug();
                if (fahrzeug != null && fahrzeug.getNummernschild().equalsIgnoreCase(nummernschild)) {
                    return new Position(etage.getNummer(), i);
                }
            }
        }
        return null;
    }

    public boolean fahrzeugIstBereitsImParkhaus(String nummernschild) {
        return findeFahrzeugPosition(nummernschild) != null;
    }

    public int anzahlFreiePlaetze() {
        int frei = 0;
        for (Etage etage : etagen) {
            for (Parkplatz platz : etage.getPlaetze()) {
                if (platz.istFrei()) frei++;
            }
        }
        return frei;
    }

    public int getGesamtPlaetze() {
        return etagen.stream()
                     .mapToInt(et -> et.getPlaetze().size())
                     .sum();
    }
}
