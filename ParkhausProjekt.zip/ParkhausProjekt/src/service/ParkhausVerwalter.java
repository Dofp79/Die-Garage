package service;

import model.*;

public class ParkhausVerwalter {
    private Parkhaus parkhaus;

    public ParkhausVerwalter(int etagen, int plaetzeProEtage) {
        this.parkhaus = new Parkhaus(etagen, plaetzeProEtage);
    }

    public void einparken(Fahrzeug fahrzeug) {
        if (parkhaus.fahrzeugIstBereitsImParkhaus(fahrzeug.getNummernschild())) {
            System.out.println("Fahrzeug ist bereits im Parkhaus.");
            return;
        }

        Position position = parkhaus.findeFreienPlatz();
        if (position == null) {
            System.out.println("Kein freier Parkplatz verfügbar.");
        } else {
            parkhaus.parkeEin(fahrzeug, position);
            System.out.println("Fahrzeug geparkt: " + position);
        }
    }

    public void ausparken(String nummernschild) {
        Position position = parkhaus.findeFahrzeugPosition(nummernschild);
        if (position == null) {
            System.out.println("Fahrzeug nicht im Parkhaus gefunden.");
        } else {
            parkhaus.entferneFahrzeug(position);
            System.out.println("Fahrzeug wurde ausgeparkt von: " + position);
        }
    }

    public Position sucheFahrzeug(String nummernschild) {
        return parkhaus.findeFahrzeugPosition(nummernschild);
    }

    public void zeigeFreiePlaetze() {
        int frei = parkhaus.anzahlFreiePlaetze();
        System.out.println("Freie Parkplätze: " + frei + " von " + parkhaus.getGesamtPlaetze());
    }
}
